package AnimalsNurseryAccounting;

import AnimalsNurseryAccounting.util.Counter;

public class Main {
    public static void main(String[] args) {
        App.run();
    }
}
